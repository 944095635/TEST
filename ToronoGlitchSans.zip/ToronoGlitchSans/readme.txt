## 瀞ノグリッチ黒体
by RAPTORTYPE | あまずさ鴒

---

■フォント名
日本語：瀞ノグリッチ黒体
English: Torono Glitch Sans

■配布ファイル
瀞ノグリッチ黒体H1
瀞ノグリッチ黒体H2
瀞ノグリッチ黒体H3
瀞ノグリッチ黒体H4

各ファイルOpenTypeとTrueTypeが付属しています。

■ベースフォント
源ノ角ゴシック JP V2.001 (Adobe, Google)

■注意事項
- 本フォントの利用規約は源ノ角ゴシックの利用規約に準じます。
  - 2021年6月時点ではSIL OPEN FONT LICENSE Version 1.1を継承します。
    https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL
    https://licenses.opensource.jp/OFL-1.1/OFL-1.1.html
- 本フォントを利用したことによって発生したいかなる故障・損害についても責任を負いません。
- 機械的な処理を行っているため、一部に崩れている文字が含まれる場合があります。
- 縦書きは対応していません。

---

RAPTORTYPE
あまずさ鴒
HP : microraptor.booth.pm
Mail : amazusa0@gmail.com
Twitter : @AmazusaRei

---

-履歴
2021/06/17  瀞ノグリッチ黒体 ver1.0   公開

